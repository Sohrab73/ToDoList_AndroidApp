package com.example.todonosqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String> array_list;
    private ArrayAdapter<String> arrayAdapter;
    private ListView lvitems;
    Button AddItem;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final DatabaseHelper helper=new DatabaseHelper(this);
        final ArrayList array_list = helper.getAllContacts();

        lvitems=(ListView) findViewById(R.id.lvitems);

        final ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,array_list);

        lvitems.setAdapter(arrayAdapter);


        findViewById(R.id.addbtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edittext=(EditText) findViewById(R.id.edittext);
                String itemText=edittext.getText().toString();
                array_list.addAll(helper.getAllContacts());
                arrayAdapter.add(itemText);
                edittext.setText("");

                arrayAdapter.notifyDataSetChanged();
                lvitems.refreshDrawableState();
            }
        });



        setupListViewListener();
    }

//    private void setupListViewListener() {
//     lvitems.setOnItemLongClickListener((adapter, view, position, id) -> {
//         array_list.remove(position);
//         arrayAdapter.notifyDataSetChanged();
//         return true;
//     });
//
//    }
    private void setupListViewListener(){
        lvitems.setOnItemLongClickListener((adapter, view,));
    }
}

